package com.itc.commons.core.utils;

import com.google.gson.Gson;

public final class GsonUtil {

  public static final Gson GSON = new Gson();

  private GsonUtil() {}
}
