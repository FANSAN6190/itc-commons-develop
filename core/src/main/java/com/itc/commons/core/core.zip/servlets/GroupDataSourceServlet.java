package com.itc.commons.core.servlets;

import static com.adobe.granite.rest.Constants.CT_JSON;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.itc.commons.core.services.GroupService;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;

/**
 * Return fetched groups as a JSON response
 */
@Component(
  service = Servlet.class,
  immediate = true,
  property = {
    Constants.SERVICE_DESCRIPTION + "=All AEM Groups DataSource",
    "sling.servlet.paths=/bin/groupdatasource",
    "sling.servlet.methods=GET, POST"
  }
)
public class GroupDataSourceServlet extends SlingAllMethodsServlet {

    private static final Logger LOG = LoggerFactory.getLogger(GroupDataSourceServlet.class);
    private static final Gson GSON = new Gson();

    @Reference
    private GroupService groupService;

    /**
     * @param request HTTP request to fetch groups
     * @param response HTTP response with available groups
     * @throws ServletException in case of servlet-level issues
     * @throws IOException if an input/output error occurs
     */
    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
      throws ServletException, IOException {

        try {
            List<Map<String, String>> groups = groupService.fetchGroups(request.getResourceResolver());
            writeJsonResponse(response, groups, HttpServletResponse.SC_OK);

        } catch (RepositoryException e) {
            LOG.error("Error while fetching group data: {}", e.getMessage(), e);
            writeJsonResponse(response,
              Map.of("error", "Internal Server Error while fetching groups"),
              HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @param request HTTP request to post form data
     * @param response HTTP response after performing operation
     * @throws IOException if an input/output error occurs
     */
    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {

        LOG.info("Received POST request Form");

        try {
            String json = IOUtils.toString(request.getReader());
            JsonObject jsonObject = JsonParser.parseString(json).getAsJsonObject();

            String category = jsonObject.has("category") ? jsonObject.get("category").getAsString() : "";
            String brand = jsonObject.has("brand") ? jsonObject.get("brand").getAsString() : "";
            String subBrand = jsonObject.has("subBrand") ? jsonObject.get("subBrand").getAsString() : "";
            String campaignName = jsonObject.has("campaignName") ? jsonObject.get("campaignName").getAsString() : "";
            String group = jsonObject.has("group") ? jsonObject.get("group").getAsString() : "";

            LOG.info("Form data received");

            // Call function to pass on form data
            //FormDataService.dataOperation(category, brand, subBrand, campaignName, group);

            LOG.info("Operation done on Form data");
            writeJsonResponse(response, "Form data passed On", HttpServletResponse.SC_ACCEPTED);

        } catch (JsonSyntaxException | IllegalStateException e) {
            LOG.error("Invalid JSON format", e);
            writeJsonResponse(response, Map.of("error", "Invalid JSON format"), HttpServletResponse.SC_BAD_REQUEST);
        } catch (IOException e) {
            LOG.error("Error reading request body", e);
            writeJsonResponse(response, Map.of("error", "Error reading request"), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @param response HTTP response
     * @param result json payload on response
     * @param status Returns status code of response
     * @throws IOException if in
     */
    private void writeJsonResponse(SlingHttpServletResponse response, Object result, int status) throws IOException {
        response.setContentType(CT_JSON);
        response.setCharacterEncoding("UTF-8");
        response.setStatus(status);
        try (PrintWriter out = response.getWriter()) {
            out.write(GSON.toJson(result));
        }
    }
}